 #!/bin/bash

source /etc/timezone-helper/timezone-helper.conf
echo "Running the timezone-helper air-update application"
java -jar ${EXECUTION_FILE_PATH}/timezone-helper-1.0-shaded.jar \
--timezone ${COUNTRY} \
--repeat.interval.ms ${REPEAT_INTERVAL_MS} \
--log.file.path ${LOG_FILE_PATH}